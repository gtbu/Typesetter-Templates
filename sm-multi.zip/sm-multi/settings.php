<?php

$themeDir = dirname($page->theme_path); 

$page->head_js[] = $themeDir.'/js/jquery.smartmenus.js';
$page->head_js[] = $themeDir.'/js/scrolltop.js';
// $page->head_js[] = $themeDir.'/js/index.js';

 
