// can play with the offset value to get the smooth results you are looking for.

var stickyEl = document.querySelector('.sticky'); 
// In diesem Beispiel wird das erste Element des Dokuments mit der Klasse "me_sticky" zurückgegeben:

var stickyPosition = stickyEl.getBoundingClientRect().top;   
//Die Methode Element.getBoundingClientRect()  gibt die Größe eines Elementes und dessen relative Position zum Viewport zurück.

var offset = -20;

window.addEventListener('scroll', function() {
    if (window.pageYOffset >= stickyPosition + offset) {
        stickyEl.style.position = 'fixed';
        stickyEl.style.top = '0px';
    } else {
        stickyEl.style.position = 'static';
        stickyEl.style.top = '';
    }
});

// smartmenu ---------------------------------------------------------------

$('nav.wrap ul:first').addClass('extra').attr('id', 'main-menu')

$('ul.sm').attr('id', 'main-menu');
$(function(){

  $('ul.sm').first()
    .attr('id', 'main-menu')
      .find('li').each(function(n){
        $(this).attr("id", "link" + n);
      });

});

$(function() {
	$('#main-menu').smartmenus({
		mainMenuSubOffsetX: -1,
		subMenusSubOffsetX: 10,
		subMenusSubOffsetY: 0
	});
});

// SmartMenus mobile menu toggle button
$(function() {
  var $mainMenuState = $('#main-menu-state');
  if ($mainMenuState.length) {
    // animate mobile menu
    $mainMenuState.change(function(e) {
      var $menu = $('#main-menu');
      if (this.checked) {
        $menu.hide().slideDown(250, function() { $menu.css('display', 'block'); });
      } else {
        $menu.show().slideUp(250, function() { $menu.css('display', 'none'); });
      }
    });
    // hide mobile menu beforeunload
    $(window).bind('beforeunload unload', function() {
      if ($mainMenuState[0].checked) {
        $mainMenuState[0].click(); 
      }
    });
	
	 }
});