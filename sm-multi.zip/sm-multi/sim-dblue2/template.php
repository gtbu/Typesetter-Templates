<?php
global $page, $config;
$lang = isset($page->lang) ? $page->lang : $config['language'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
	<?php 	$page->head_js[] = rawurldecode($page->theme_path).'/index.js';  ?>
		
		<?php gpOutput::GetHead(); ?>
	
	<link rel="shortcut icon" href="themes/h5/favicon.ico" />
	<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
	<!--[if lt IE 9]><?php
		// HTML5 shim, for IE6-8 support of HTML5 elements
		gpOutput::GetComponents( 'html5shiv' );
		gpOutput::GetComponents( 'respondjs' );
		?><![endif]-->
</head>
<body>
<div class=globalwrap>

	<header> 
	<div class="hero">
		<div class=title><?php gpOutput::Get('Extra','Header'); ?></div>
		&nbsp;
<div class=search>				
<form action="index.php/Search" method="get">
<div>
<input class="text" name="q" type="text" value=""> 
<input name="src" type="hidden" value="gadget"> &nbsp;
<input class="submit" name="" type="submit" value="Suche">
</div>
</form> 
</div>
</div> <!-- hero -->

</header>
	
	 <!-- Mobile menu toggle button (hamburger/x icon) -->
<input id="main-menu-state" type="checkbox" />
<label class="main-menu-btn" for="main-menu-state">
  <span class="main-menu-btn-icon"></span> Toggle main menu visibility
</label>

	<nav  class="wrap main_nav sticky" role="navigation">	
	  	<?php 
		$GP_ARRANGE = false;
		$GP_MENU_CLASS = "sm sm-simple";
		gpOutput::Get('FullMenu');
		?>
	</nav>
<br>

<div class="section">
	<div id="page" class="page_wrap">
		<div id="content" class="wrapc" >
			<?php $page->GetContent(); ?>
		</div>		
	</div>
<br>
	<div class="footer">						
		<p class="footerlinks">
		<?php gpOutput::GetAdminLink(); ?></p>		
	</div>
</div>
</body>
</html>
