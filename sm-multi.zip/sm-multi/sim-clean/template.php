<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
	<?php 	$page->head_js[] = rawurldecode($page->theme_path).'/index.js';  ?>
	<?php gpOutput::GetHead(); ?>
	
	<link rel="shortcut icon" href="themes/h5/favicon.ico" />
	<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
	<!--[if lt IE 9]><?php
		// HTML5 shim, for IE6-8 support of HTML5 elements
		gpOutput::GetComponents( 'html5shiv' );
		gpOutput::GetComponents( 'respondjs' );
		?><![endif]-->
</head>
<body>
<div id=gwrap class=gwrap>
	<header class="wrap bgbg">
		<?php
		global $config;
		$default_value = $config['title'];
		$GP_ARRANGE = false;
		gpOutput::GetArea('header',$default_value);
		?>
	</header>
	
	<nav class="main-nav" role="navigation">	
	
  <!-- Mobile menu toggle button (hamburger/x icon) sm-vertical -->
  <input id="main-menu-state" type="checkbox" />
  <label class="main-menu-btn" for="main-menu-state">
    <span class="main-menu-btn-icon"></span> Toggle main menu visibility
  </label>
 
		<?php 
		$GP_ARRANGE = false;
		$GP_MENU_CLASS = "sm sm-clean"; 
		gpOutput::Get('FullMenu');
		?>
	</nav>
	
<div class="section">
	<div id="page" class="main page_wrap">
		<div id="content" class="content wrapc" >	
		<?php $page->GetContent(); ?>
		</div>
   </div>
	<br>
	
	<div class="footer">			
      
		<p class="footerlinks"> 		<?php gpOutput::GetAdminLink(); ?></p>		
	</div>
	
		
</div>
	
</div> <!-- gwrap -->
</body>
</html>
