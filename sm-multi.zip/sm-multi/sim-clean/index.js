 $('nav.main-nav ul:first').addClass('sm sm-clean').attr('id', 'main-menu')   

$(function(){
  $('ul.sm').first()
    .attr('id', 'main-menu')  
	/* ---ok dominiert --- */
      .find('li').each(function(n){
        $(this).attr("class", "link" + n);
      });

});

/* --------------------------------------------------------------------------------------- */

$(function() {
	$('.main-nav').click(function() {
		$('#main-menu-state').click();
	});
});


/* ------------------------------------------------------------------------------------------*/
/*  SmartMenus init  */

$(function() {
  $('#main-menu').smartmenus({
    mainMenuSubOffsetX: -1,
    mainMenuSubOffsetY: 4,
    subMenusSubOffsetX: 6,
    subMenusSubOffsetY: -6
  });
});

/* --- SmartMenus mobile menu toggle button https://www.smartmenus.org/docs/ --- */

$(function() {
  var $mainMenuState = $('#main-menu-state');  
    if ($mainMenuState.length) {
    // animate mobile menu
    $mainMenuState.change(function(e) {
      var $menu = $('#main-menu');
      if (this.checked) {
        $menu.hide().slideDown(250, function() { $menu.css('display', 'block'); });
      } else {
        $menu.show().slideUp(250, function() { $menu.css('display', 'none'); });
      }
    });
	
    // hide mobile menu beforeunload
    $(window).bind('beforeunload unload', function() {
      if ($mainMenuState[0].checked) {
        $mainMenuState[0].click();
      }
    });
	 //oder auch 
	$(window).on('beforeunload unload', function() {
      if ($mainMenuState[0].checked) {
        $mainMenuState[0].click();
      }
    });
  }
});