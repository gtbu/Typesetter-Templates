
/* bootstrap 5 js-menu additions --- */

$( "div.gpMenu ul.navbar-nav li.nav-item a" ).addClass("nav-link");

$( "div.gpMenu ul.navbar-nav ul.dropdown-menu li a").removeClass("nav-link").removeClass("dropdown-toggle");

$( "div.gpMenu ul.navbar-nav ul.dropdown-menu li.nav-item").addClass("dropdown"); 

$( "div.gpMenu ul.navbar-nav li.nav-item.dropdown a" ).addClass("dropdown-toggle").attr("data-bs-toggle", "dropdown");  /* ok */

$( "div.gpMenu ul.dropdown-menu li").removeClass("nav-item").removeClass("dropdown");

$( "div.gpMenu ul.dropdown-menu li a").removeClass("dropdown-toggle").addClass("dropdown-item").attr("data-bs-toggle", ""); 



