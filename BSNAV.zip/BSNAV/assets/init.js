﻿
/*  -------------- navigation ------------------ */

$("ul.navbar-nav li").addClass("nav-item");  

$("li.nav-item a").addClass("nav-link"); 

$("div.gpArea_FullMenu.GPAREA ul").addClass("navbar-nav");

$("ul.navbar-nav.navbar-mobile li:last-child").addClass("dropdown-right");

 $("li.nav-item.dropdown > a.nav-link:first-child").each(function() {
  $(this).append('<i class="caret"></i>'); }); 

/* --------------------------------------------------- */

    




