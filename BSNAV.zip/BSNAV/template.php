<?php
/**
 * Theme Bsnav - sdt
 * Typesetter CMS theme template
 **/

global $page, $config;

common::LoadComponents( 'fontawesome' );
$lang = isset($page->lang) ? $page->lang : $config['language'];

/**
 * If you are using Multi-Language Manager 1.2.3+
 * and want to use localized $langmessage values in the template,
 * uncomment the following line
 */
 // common::GetLangFile('main.inc', $lang);

?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" class="bootstrap-4">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

    <?php  gpOutput::GetHead(); ?>

  </head>
  
 <body>
    <!--[if lte IE 9]>
      <div class="alert alert-warning">
        <h3>Bootstrap 4</h3>
        <p>We&rsquo;re sorry but Internet Explorer 9 support was dropped as of Bootstrap version 4.</p>
      </div>
    <![endif]-->
 <div class="wrap d-flex flex-column min-vh-100">	
 <header class="main-header">
              
 <div class="navbar navbar-expand-md bsnav bsnav-overlay bsnav-sticky">
   <div class="container-fluid">
   
    <?php  global $config; echo common::Link('',$config['title'],'','class="navbar-brand"'); ?>
          		  
		   <div id="search">		  
		  <?php		//search form
						global $langmessage;
						$_GET += array('q'=>'');
						?>
						
				<form action="<?php echo common::GetUrl( 'special_gpsearch') ?>" method="get">
					<div class="input-group">
						<input name="q" type="text" class="form-control" value="<?php echo htmlspecialchars($_GET['q']) ?>" 
						placeholder="<?php echo $langmessage['Search'] ?>">
							<span class="input-group-btn">
								<button type="submit" class="btn btn-default" type="button">
									<span class="fa fa-search" aria-hidden="true"></span>
								</button>
							</span>
				    </div> 						</form>
		  </div>	
		  
		  
		  
         <button class="navbar-toggler toggler-spring"><span class="navbar-toggler-icon"></span></button>
			
          <div class="collapse navbar-collapse justify-content-md-end">
            <?php
              $GP_ARRANGE = false;
              // main nav classes
              $GP_MENU_CLASSES = array(
                'menu_top'          => 'navbar-nav navbar-mobile mr-0 bg-nav',
                'selected'          => 'active',
                'selected_li'       => 'selected',
                'childselected'     => 'active',
                'childselected_li'  => '', // use '' if you do not want 1st-level nav items to indicate that a child item is active
                'li_'               => 'nav-item',
                'li_title'          => '',
                'haschildren'       => 'dropdown',
                'haschildren_li'    => 'dropdown',
                'child_ul'          => 'abc dropdown',
              );

              gpOutput::Get('FullMenu'); //all two levels
            ?>
          </div><!--/.navbar-collapse -->
        </div>
      </div>
    </header><!-- /.main-header -->

 <div class="main-content">
	  <div class="jumbotron jumbotron-fluid">
      <div class="container-fluid jumbo">
        <h1>Jumbotron</h1>
		<p>BSNAV overlay</p>
      </div>
      </div>
	  
      <div class="container-fluid content">
        <?php $page->GetContent(); ?>
      </div><!-- /.container-->
 </div><!-- /.main-content -->

<!-- ----  mobile X and button  ---------------------- -->	  
 <div class="bsnav-mobile">
      <div class="bsnav-mobile-overlay"></div>			  
      <div class="navbar bsnav mob"></div> 
 </div>
	  
<!-- ---- footer  ---------------------- -->	  
	  
  </div><!-- /.wrap -->
  
  <footer class="main-footer pt-5 pb-5 mt-5">
      <div class="container-fluid">

        <div class="row">
          <div class="col-sm-6 col-lg-3 footer-column footer-column-1">
            <?php gpOutput::Get('Extra', 'Footer_bs_1'); ?>
          </div>

          <div class="col-sm-6 col-lg-3 footer-column footer-column-2">
            <?php gpOutput::Get('Extra', 'Footer_bs_2'); ?>
          </div>

          <div class="col-sm-6 col-lg-3 footer-column footer-column-3">
            <?php gpOutput::Get('Extra', 'Footer_bs_3'); ?>
          </div>

          <div class="col-sm-6 col-lg-3 footer-column footer-column-4">
             <?php gpOutput::GetAdminLink(); ?>
          </div>
        </div><!-- /.row -->

      </div><!-- /.container -->
    </footer><!-- /.main-footer -->
  
  </body>
</html>
