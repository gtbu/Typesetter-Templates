<?php
$GP_GETALLGADGETS = true;
/*
$link = common::Link('','%s');
gpOutput::Area('header','<h1>'.$link.'</h1>');
gpOutput::Area('link_label','<h3>%s</h3>');
*/

include 'drop_down_menu.php';

$themeDir = dirname($page->theme_path); 
$page->head_js[] = $themeDir.'/assets/bsnav.min.js';
$page->head_js[] = $themeDir.'/assets/bootstrap45.min.js';
$page->head_js[] = $themeDir.'/assets/nitro.min.js';
$page->head_js[] = $themeDir.'/assets/init.js';

global $page;
