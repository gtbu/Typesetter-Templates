Version 2.0 of the smartstrap4 - template for Typesetter CMS is under MIT - License just as Bootstrap 4.5 and Smartmenus.

It contains several colors and a jumbotron and a sidebar-template.


* The various templates switch to the hamburger at different sizes, which are adjustable in the specific color-template.php

in <div class="navbar navbar-expand-md fixed-top  from navbar-expand-sm to navbar-expand-md until navbar-expand-lg.


* The length of the search-filed is adjustable as input.form-control {max-width:120px;} /* searchfield */


