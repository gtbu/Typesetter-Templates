<?php

global $page, $config;
$path = $page->theme_dir . '/drop_down_menu.php';
include_once($path);
$lang = isset($page->lang) ? $page->lang : $config['language'];

include($page->theme_dir . '/' . $page->theme_color . '/template.php');

/*$page->head_js[] = rawurldecode($page->theme_path).'/../assets/js/bootstrap.min.js'; 
$page->head_js[] = rawurldecode($page->theme_path).'/../assets/js/popper.min.js';  
$page->head_js[] = rawurldecode($page->theme_path).'/../assets/js/jquery.smartmenus.js';
$page->head_js[] = rawurldecode($page->theme_path).'/../assets/js/jquery.smartmenus.bootstrap-4.js';
$page->head_js[] = rawurldecode($page->theme_path).'/../assets/js/init.js'; */

