<?php
$GP_GETALLGADGETS = true;
/*
$link = common::Link('','%s');
gpOutput::Area('header','<h1>'.$link.'</h1>');
gpOutput::Area('link_label','<h3>%s</h3>');
*/
/* for user specific entries */

global $page;
$themeDir = dirname($page->theme_path); 

$page->head_js[] = $themeDir.'/assets/js/popper.min.js'; /* not necessary while login*/
$page->head_js[] = $themeDir.'/assets/js/bootstrap45.min.js'; 
$page->head_js[] = $themeDir.'/assets/js/jquery.smartmenus.js';
$page->head_js[] = $themeDir.'/assets/js/jquery.smartmenus.bootstrap-4.js';
$page->head_js[] = $themeDir.'/assets/js/init.js';