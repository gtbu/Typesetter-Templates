<?php
$GP_GETALLGADGETS = true;
/*
$link = common::Link('','%s');
gpOutput::Area('header','<h1>'.$link.'</h1>');
gpOutput::Area('link_label','<h3>%s</h3>');
*/

global $page;

$themeDir = dirname($page->theme_path); 

$page->head_js[] = $page->theme_path . '/script2.js';



