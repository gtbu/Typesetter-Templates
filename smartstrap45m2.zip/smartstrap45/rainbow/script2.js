/* user theme extra inits */

/* document.querySelectorAll('h2').forEach(function(el, i){
  el.id = i;   el.classList.add('Class');
}); */



$('.content p').addClass('animated slideInRight bg-faded p-5.my-3').attr('id,anim-body');

/* https://jackonthe.net/css3animateit/examples */
$('.content h2').addClass('animated rotateIn');

 
$('ul.dropdown-menu:nth-child(2)').addClass('animated rotateIn');

$('div#search').addClass('animated bounceInRight'); 