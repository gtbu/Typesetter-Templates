<?php

$GP_GETALLGADGETS = true;

/*
$link = common::Link('','%s');
gpOutput::Area('header','<h1>'.$link.'</h1>');
gpOutput::Area('link_label','<h3>%s</h3>');
*/

/* for user specific entries */

global $page;
$themeDir = dirname($page->theme_path); 
$path = $page->theme_dir . '/drop_down_menu.php';
//include_once($path);
/**
 * Include current layout settings
 */
include($page->theme_dir . '/' . $page->theme_color . '/settings.php');
$page->head_js[] = $themeDir.'/assets/js/bootstrap.bundle.min.js'; 
$page->head_js[] = $themeDir.'/assets/js/init.js';

