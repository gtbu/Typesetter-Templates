<?php
$GP_GETALLGADGETS = true;
/*
$link = common::Link('','%s');
gpOutput::Area('header','<h1>'.$link.'</h1>');
gpOutput::Area('link_label','<h3>%s</h3>');
*/

global $page;

$layout_js = $page->theme_dir . '/' . $page->theme_color . '/script2.js';

if( file_exists($layout_js) ){
	$page->head_js[] = rawurldecode($page->theme_path) . '/script2.js';
}


$themeDir = dirname($page->theme_path); 

$page->head_js[] = $page->theme_path . '/script2.js';


