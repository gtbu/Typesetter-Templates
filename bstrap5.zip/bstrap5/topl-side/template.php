<?php

/* bstrap5 Typesetter Theme 
 *  MIT License
 * by github.com/gtbu
 */

global $page, $config;

$pwth = $page->theme_dir . '/' . $page->theme_color . '/settings.php';
include_once($pwth);

$lang = isset($page->lang) ? $page->lang : $config['language'];
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" class="bootstrap-5 w100">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

    <?php 
	    gpOutput::GetHead();
    ?>

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <!-- <link href="../../assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet"> -->

  </head>
<body class="">
    <!--[if lte IE 9]>
      <div class="alert alert-warning">
        <h3>Bootstrap 4</h3>
        <p>We&rsquo;re sorry but Internet Explorer 9 support was dropped as of Bootstrap version 4.</p>
      </div>
    <![endif]-->
	
<div class="wrap">	
	
 <nav class="navbar navbar-expand-lg navbar-light sticky-top bg-custom" id="navbar_top">
 
   <div class="container uwrap row">   
           <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#main_nav" aria-expanded="false" aria-label="Toggle navigation">
             <span class="navbar-toggler-icon"></span>
           </button>
	
            <div class="collapse navbar-collapse col-md-8  px-2" id="main_nav">           
              <?php
              $GP_ARRANGE = false;
              $GP_MENU_CLASSES = array(
                'menu_top'          => 'navbar-nav me-auto col-sm-9 ms-auto mb-2 mb-lg-0',
			    'selected'          => 'active',
                'selected_li'       => 'sel',
                'childselected'     => 'active',
                'childselected_li'  => 'active',  // use '' if you don't want 1st-level nav items to indicate that a dropdown item is active 
                'li_'               => 'nav-item nav-item-',
				'li_title'          => 'ttt',
                'haschildren'       => 'dropdown-toggle',
                'haschildren_li'    => 'dropdown',
			    'child_ul'          => 'dropdown-menu animate__animated animate__fadeIn',
              );

              gpOutput::Get('FullMenu'); //top two levels
              ?>
		    </div>
            <!-- </div><!-- /.navbar-collapse -->
		  
		    <div id="space" class="col-md-1">. </div>	
		   
		    <div id="search" class="col-md-3 justify-content-end float-right">		  
		            <?php		//search form
						global $langmessage;
						$_GET += array('q'=>'');
					?>
						
				<form action="<?php echo common::GetUrl( 'special_gpsearch') ?>" method="get" class="fmail">
					<div class="input-group">
						<input name="q" type="text" class="form-control" value="<?php echo htmlspecialchars($_GET['q']) ?>" 
						placeholder="<?php echo $langmessage['Search'] ?>">
							<span class="input-group-btn">
								<button type="submit" class="btn btn-default" type="button">
									<i class="bi bi-search"></i>
								</button>
							</span>
				    </div> 						
				</form>
		    </div>	<!-- search -->	
           		
       </div> <!-- uwrap -->
    </nav>
	

   <div class="main-content row">
	
      <div class="container content col py-3 bg-light shadow-sm">
        <?php $page->GetContent(); ?>
      </div><!-- /.container-->
	  
	  <div class="side ccol-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-light shadow-sm">
	    <?php gpOutput::Get('Extra', 'Side_bt5_2'); ?> 
	  </div>
	   
    </div><!-- /.main-content -->

 </div><!-- wrap -->

    <footer class="main-footer pt-5 pb-5 mt-3">
      <div class="container">	  
        <div class="sm4 row">
          <div class="col-sm-5 footer-column footer-column-1">
              <?php gpOutput::Get('Extra', 'Footer_b5hl-col_1'); ?> <!-- to create under content -> extra content -->
          </div>
          <div class="col-sm-4 footer-column footer-column-2">
              <?php gpOutput::Get('Extra', 'Footer_b5hl-col_2'); ?>
          </div>       
          <div class="col-sm-3 footer-admin-links">
             <i class="bi bi-list-ul" style="color:white; -webkit-text-stroke: 1px;"></i>
			 <?php gpOutput::GetAdminLink(); ?>
			  <br>
			  &copy; <?php  echo date("Y"); ?> thisdomain.com
          </div>		  
        </div><!-- /.row -->
      </div><!-- /.container -->
	  
    </footer><!-- /.main-footer -->
	
  </body>
</html>