<?php

global $page, $config;

$lang = isset($page->lang) ? $page->lang : $config['language'];

include($page->theme_dir . '/' . $page->theme_color . '/template.php');

/* common::LoadComponents('fontawesome'); */
        

