This package contains more than 40 themes from bootpress.org, which are 
released under the MIT license.

The nav is based on https://github.com/vadikom/smartmenus-bootstrap /smartmenus.org), which 
has MIT license.

The package is published under MIT license.

Version 2.0 corrects a bug with the hamburger and updates to bootstrap 3.4.1.
It includes the new 3.4.1 js and less.

