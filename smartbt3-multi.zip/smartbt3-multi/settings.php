<?php
$GP_GETALLGADGETS = true;
/*
$link = common::Link('','%s');
gpOutput::Area('header','<h1>'.$link.'</h1>');
gpOutput::Area('link_label','<h3>%s</h3>');
*/

$themeDir = dirname($page->theme_path); 

$page->head_js[] = $themeDir.'/assets/jquery.smartmenus.js';
$page->head_js[] = $themeDir.'/assets/jquery.smartmenus.bootstrap.min.js';

$page->head_js[] = $themeDir.'/assets/bootstrap.min.js';
$page->head_js[] = $themeDir.'/assets/init.js';

global $page;
// removed  $page->head .= '<link rel="stylesheet" type="text/css" href="'.$themeDir.'/assets/jquery.smartmenus.bootstrap.css'.'" />';
// removed  $page->head .= '<link rel="stylesheet" type="text/css" href="'.$themeDir . '/' . $page->theme_color . '/bootstrap.min.css'.'" />';