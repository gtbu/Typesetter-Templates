<?php
global $page, $config;
$lang = isset($page->lang) ? $page->lang : $config['language'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
			
		
	<?php 	gpOutput::GetHead(); 		?>

		<!--[if lt IE 9]><?php
		// HTML5 shim, for IE6-8 support of HTML5 elements
		gpOutput::GetComponents( 'html5shiv' );
		gpOutput::GetComponents( 'respondjs' );
		?><![endif]-->

</head>

	<body>
		<div class="navbar navbar-default navbar-fixed-top" role="navigation">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					
					<?php
					global $config;
					echo common::Link('',$config['title'],'','class="navbar-brand"');
					?>
				</div>
				
				<div class="collapse navbar-collapse">
					<?php
					$GP_ARRANGE = false;
					$GP_MENU_CLASSES = array(
							'menu_top'			=> 'nav navbar-nav',   // <ul class="nav navbar-nav">
							'selected'			=> '',
							'selected_li'		=> 'active',
							'childselected'		=> '',
							'childselected_li'	=> '',
							'li_'				=> '',
							'li_title'			=> '',
							'haschildren'		=> 'dropdown-toggle',
							'haschildren_li'	=> 'dropdown',
							'child_ul'			=> 'dropdown-menu',
							);

					// gpOutput::Get('TopTwoMenu'); //top two levels
					
					gpOutput::Get('FullMenu'); 
					?>
				</div><!--/.nav-collapse -->
			</div>
		</div>
		<div class="container">
		<?php if (common::LoggedIn()) echo "logged"; ?>
		</div>
		<!-- Page Content -->
	<div class="container">
			<div class="row">
				<!-- Content -->
				<div class="col-md-9 content">
					<?php
					$page->GetContent();
					?>							
				</div>
				
				<!-- Blog Sidebar Widgets Column -->
				<div class="col-md-3">
					<!-- Blog Search Well -->
					<div class="well">
						<?php
						//search form
						global $langmessage;
						$_GET += array('q'=>'');
						?>
						<h4><?php echo $langmessage['Search'] ?></h4>
						<form action="<?php echo common::GetUrl( 'special_gpsearch') ?>" method="get">
							<div class="input-group">
								<input name="q" type="text" class="form-control" value="<?php echo htmlspecialchars($_GET['q']) ?>" placeholder="<?php echo $langmessage['Search'] ?>">
								<span class="input-group-btn">
									<button type="submit" class="btn btn-default" type="button">
										<span class="glyphicon glyphicon-search"></span>
									</button>
								</span>
							</div>
						</form>
					</div>
					<!-- Blog Categories Well -->
					<div class="well">
						<?php
							gpOutput::GetAllGadgets();
						 ?>
					</div>
										
                </div>
              
			</div>
		
		<hr />

		<footer>			
		 <div class="footer row">
           <div class="col-sm-6 col-lg-3 footer-column footer-column-1">
            <?php gpOutput::Get('Extra', 'Footer_Col_1'); ?>
           </div>

           <div class="col-sm-6 col-lg-3 footer-column footer-column-2">
            <?php gpOutput::Get('Extra', 'Footer_Col_2'); ?>
           </div>

           <div class="col-sm-6 col-lg-3 footer-column footer-column-3">
            <?php gpOutput::Get('Extra', 'Footer_Col_3'); ?>
           </div>

           <div class="col-sm-6 col-lg-3 footer-column footer-column-4">
            <p>	<?php gpOutput::GetAdminLink();		?></p>
           </div>
         </div>
		</footer>
			
</div>
		<!-- container -->

</body>

</html>
